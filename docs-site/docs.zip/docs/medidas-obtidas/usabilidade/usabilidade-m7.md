# Usabilidade - M7: Percentual de compatibilidade com leitores de tela.
## Introdução

Na presente execução da análide de usabilidade do Agromart, foi definida, durante a [Fase 2](https://fcte-qualidade-de-software-1.github.io/2025-1-T01--Betty-Snyder/gqm/gqm/#selecao-das-metricas) do projeto, métricas voltadas à avaliação da experiência do usuário com enfoque mobile-first. 
Esse documento tem como objetivo sintetizar os achados referentes à métrica M7 (Percentual de compatibilidade com leitores de tela.), considerada essencial para avaliar a usabilidade do sistema em dispositivos móveis.

## Referencial teórico 

Segundo a norma ISO/IEC 25010, a 

## Análise

## Execuçaõ da análise

## Resultados

## Bibliografia

## Referências Bibliográficas

## Histórico de Versões

|Versão|Data|Descrição|Autor|Revisor|
|:----:|----|---------|-----|:-------:|
|`1.0`|07/07/2025|Criação do documento| [Ana Júlia](https://github.com/ailujana) ||